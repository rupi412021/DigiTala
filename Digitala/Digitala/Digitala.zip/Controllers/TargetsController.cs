﻿using Digitala.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Digitala.Controllers
{
    public class TargetsController : ApiController
    {
        [HttpGet]
        [Route("api/Targets")]
        public List<Targets> Get()
        {
            Targets t = new Targets();
            List<Targets> tlist = t.Read();
            return tlist;
        }

        [HttpDelete]
        [Route("api/Targets")]
        public List<Targets> Delete([FromBody]Targets t)
        {
            return t.Delete();
        }

        [HttpPost]
        [Route("api/Targets")]
        public List<Targets> Post([FromBody]Targets t)
        {
            return t.Insert();
        }

        //[HttpPost]
        //[Route("api/Targets")]
        //public List<Targets> Post()
        //{
        //    Targets t = new Targets();
        //    return t.GetRecommendedTargets();
        //}

        [HttpPut]
        [Route("api/Targets")]
        public List<Targets> Put([FromBody]Targets t)
        {
            return t.Update();
        }
    }
}